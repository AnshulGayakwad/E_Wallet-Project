package mybeans;
import java.sql.*;

public class FundTransfer
{
	private int fromacc;
	private int toacc;
	private double amount;
	private String status;
 
	public FundTransfer()
	{
		fromacc=0;
		toacc=0;
		amount=0.0;
	    status=" ";
	}

	public String getStatus() {
		return status;
	}

	
	public void setFromacc(int fromacc) {
		this.fromacc = fromacc;
	}

	public void setToacc(int toacc) {
		this.toacc = toacc;
	}

	public void setAmount(double amount) {
		this.amount = amount;
		transfer();
	}
	
	private void transfer() 
	{
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		String type="Money Transfer";
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select balance from usersdata where walletid=?;");
			pst.setInt(1,fromacc);
			rs=pst.executeQuery();
			if(rs.next())
			{
				if(amount<rs.getDouble("balance"))
				{
					pst=con.prepareStatement(" update usersdata set balance=balance-? where walletid=? ;");
					pst.setDouble(1,amount);
					pst.setInt(2,fromacc);
					int cnt=pst.executeUpdate();
					
						if(cnt>0)
							{
								pst=con.prepareStatement("update usersdata set balance=balance+? where walletid=?;");
								pst.setDouble(1,amount);
								pst.setInt(2,toacc);
								pst.executeUpdate();
								status="success";
								
								Emailsender es=new Emailsender();
								es.sendemail(fromacc);
								
								pst=con.prepareStatement("insert into acctransactions(transdt,srcwalletid,destwalletid,transactiontype,amount) values(now(),?,?,?,?);");
					    	    pst.setInt(1,fromacc);
					    	    pst.setInt(2,toacc);
					    	    pst.setString(3,type);
					    	    pst.setDouble(4,amount);
					    	    pst.executeUpdate();
							}
		                else
		    	                status="failed";
		    
				}
				else
					status="failed";
			}
		    
		}
		catch(Exception e)
		{
			System.out.println(e);
			status="error";
		}
		
		
	}
	
}
