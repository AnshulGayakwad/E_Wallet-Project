package mybeans;

public class WalletRest 
{
	private String walletid;
	private double balance;
	
	public WalletRest ()
	{
		walletid="";
		balance = 0.0;
	}

	public String getWalletid() {
		return walletid;
	}

	public void setWalletid(String walletid) {
		this.walletid = walletid;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
}
