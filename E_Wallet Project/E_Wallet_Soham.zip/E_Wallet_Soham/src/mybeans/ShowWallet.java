package mybeans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ShowWallet {
	private String id;
	private int wid;
	private double bal;
	
	
	
	public int getWid() {
		return wid;
	}


	public void setWid(int wid) {
		this.wid = wid;
	}


	public double getBal() {
		return bal;
	}


	public void setBal(double bal) {
		this.bal = bal;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
		retrivedata();
	}

	public void retrivedata()
	{
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
	
		    pst=con.prepareStatement("select walletid,balance from usersdata where userid=?;");
		    pst.setString(1, id);
		    rs=pst.executeQuery();
		    if(rs.next())
		    {
		    	wid=rs.getInt("walletid");
		    	bal=rs.getDouble("balance");
		    }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
