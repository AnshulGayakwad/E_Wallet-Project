package mybeans;
import java.sql.*;

import com.email.durgesh.Email;

public class Emailsender {
	public String sendemail(int wid)
	{
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		String eml="";
		try {
			
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("select email from usersdata where walletid=?;");
			pst.setInt(1,wid);
			rs=pst.executeQuery();
			if(rs.next())
			{
				eml=rs.getString("email");
			}
			
			Email email=new Email("Enter Your Mail","Enter Your Mail Password");
			email.setFrom("Enter Your Mail","Enter Send From Mail");
			email.setSubject("Regarding Transactions");
			email.setContent("<h1>Payment done </h1>","text/html");
			email.addRecipient(eml);
			email.send();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "transaction details sended on ur email";
	}

}
