package mybeans;

import java.sql.*;

public class WalletBalance {
	
	public WalletRest searchBalance(String walletid)
	{
		WalletRest obj = new WalletRest();
		Connection con;
		PreparedStatement st;
		ResultSet rs;
		
		try
		{

			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			st=con.prepareStatement("select * from usersdata where walletid=?;");
			st.setString(1, walletid);
			rs=st.executeQuery();
			if(rs.next())
			{
				obj.setBalance(rs.getDouble("balance"));
			}
			else
			{
				obj.setBalance(0.0);
			}
			
			con.close();
		}
		catch(Exception e)
		{
			obj.setBalance(0.0);
			System.out.println(e);
		}
		return (obj);
	}

}
