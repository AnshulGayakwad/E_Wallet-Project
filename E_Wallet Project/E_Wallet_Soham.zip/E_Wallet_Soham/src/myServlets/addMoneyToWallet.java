package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mybeans.DBConnector;

/**
 * Servlet implementation class addMoneyToWallet
 */
@WebServlet("/addMoneyToWallet")
public class addMoneyToWallet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addMoneyToWallet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String id=request.getParameter("id");
		int accno=Integer.parseInt(request.getParameter("accno"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst= con.prepareStatement("update bankaccount set balance=balance-? where accno=?;");
			pst.setInt(1, amount);
			pst.setInt(2, accno);
			int r=pst.executeUpdate();
    	 	if(r>0)
    	 	{
    	 		pst= con.prepareStatement("update usersdata set balance=balance+? where accountno=?;");
    			pst.setInt(1, amount);
    			pst.setInt(2, accno);
    			int cnt=pst.executeUpdate();
    			if(cnt>0)
    			{
    				response.sendRedirect("MoneyAddedtoWallet.jsp");
    			}
    	 	}
			else
			{
				response.sendRedirect("Failure.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
