package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybeans.*;




/**
 * Servlet implementation class BillPayment
 */
@WebServlet("/BillPayment")
public class BillPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillPayment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Emailsender es=new Emailsender();
		
		String company=request.getParameter("fav_language");
        int id=Integer.parseInt(request.getParameter("id"));
		String type=request.getParameter("type");
		double amount=Double.parseDouble(request.getParameter("amount"));
		
		
		Connection con;
		PreparedStatement pst;
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
		    pst=con.prepareStatement("update usersdata set balance=balance-?  where walletid=?;");
		    pst.setDouble(1,amount);
		    pst.setInt(2,id);
		    int cnt=pst.executeUpdate();
		    if(cnt>0)
		    {
		    	    pst=con.prepareStatement("update companydata set balance=balance+? where companyname=?;");
				    pst.setDouble(1,amount);
				    pst.setString(2,company);
				    pst.executeUpdate();
				    
				    
					es.sendemail(id);
				    
		    	    pst=con.prepareStatement("insert into acctransactions(transdt,srcwalletid,destwalletid,transactiontype,amount) values(now(),?,?,?,?);");
		    	    pst.setInt(1,id);
		    	    pst.setString(2,company);
		    	    pst.setString(3,type);
		    	    pst.setDouble(4,amount);
		    	    pst.executeUpdate();
		    	    
		    	    if(amount>1000)
		    	    {
		    	        pst=con.prepareStatement("update companydata set balance=balance-50 where companyname=?;");
		    	        pst.setString(1,company);
					    pst.executeUpdate();
		    		    pst=con.prepareStatement("update usersdata set balance=balance+50 where walletid=?;");
		    		    pst.setInt(1,id);
		    	    	pst.executeUpdate();
		    	    	
						es.sendemail(id);
		    	    	
		    	    	pst=con.prepareStatement("insert into acctransactions(transdt,srcwalletid,destwalletid,transactiontype,amount) values(now(),?,?,'CashBack',50);");
		    	    	pst.setString(1,company);
		    	    	pst.setInt(2,id);   
			    	    pst.executeUpdate();
		    	    }
				   
				    response.sendRedirect("success.jsp");
		    }
		    else
		    	response.sendRedirect("failure.jsp");
		    
		}
		catch(Exception e)
		{
			System.out.println(e);
			response.sendRedirect("failure.jsp");
		}
		
		
	}

}