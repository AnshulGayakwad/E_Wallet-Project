package myServlets;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import mybeans.DBConnector;

/**
 * Servlet implementation class UploadKyc
 */

@MultipartConfig
@WebServlet("/UploadKyc")
public class UploadKyc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadKyc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		
		String id=request.getParameter("id");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Part file=request.getPart("profile");
		Part adhar=request.getPart("adhar");
		
		String ProfileName=id+file.getSubmittedFileName();
		String AdharcardFileName=id+adhar.getSubmittedFileName();
		
		String uploadPath ="C:/Users/Anshu/galahad/Sohams-JavaEE-Feb2020/05-Mission-IDEs/eclipse-jee-2019-12-R-win32-x86_64/JavaEEProjects-2021/E_Wallet_Soham/WebContent/KYC Folder/Profilepic/" +ProfileName;
		String uploadPathad ="C:/Users/Anshu/galahad/Sohams-JavaEE-Feb2020/05-Mission-IDEs/eclipse-jee-2019-12-R-win32-x86_64/JavaEEProjects-2021/E_Wallet_Soham/WebContent/KYC Folder/Adharcard/" +AdharcardFileName;
		
		
		String bankname=request.getParameter("bankName");
		int accno=Integer.parseInt(request.getParameter("accno"));
		String mail="";
		
		try
		{
		FileOutputStream fos=new FileOutputStream(uploadPath);
		InputStream is=file.getInputStream();
		
		
		
		byte[] data=new byte[is.available()];
		is.read(data);
		fos.write(data);
		fos.close();
		
		FileOutputStream fo=new FileOutputStream(uploadPathad);
		InputStream ist=adhar.getInputStream();
		
		byte[] dataa=new byte[ist.available()];
		ist.read(dataa);
		fo.write(dataa);
		fo.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		Connection con;
		PreparedStatement pst ;
		ResultSet rs ;
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();	
		    pst=con.prepareStatement("insert into kycdetails values(?,?,?)");
		    pst.setString(1, id);
		    pst.setString(2, ProfileName);
		    pst.setString(3, AdharcardFileName);
		    int row=pst.executeUpdate();
		    
		    if(row>0)
		    {
		    	int a = ThreadLocalRandom.current().nextInt();   
		    	String wid=String.valueOf(a).substring(1,7);
		    	 pst=con.prepareStatement("update usersdata set walletid=? where userid=?");
		    	 pst.setString(1, wid);
		    	 pst.setString(2, id);
		    	 int r=pst.executeUpdate();
		    	 	if(r>0)
		    	 		response.sendRedirect("Customer.jsp");
		    	    else 
		    	    	response.sendRedirect("failure.jsp");
		    	 	 
		    }
		    else
		    	response.sendRedirect("failure.jsp");
		    
		    
		    
		    pst=con.prepareStatement("select * from usersdata where userid=?;");
		    pst.setString(1, id);
		    rs=pst.executeQuery();
		    if(rs.next())
			{
				mail=rs.getString("email");
				
			}
		    
		    pst=con.prepareStatement("select * from bankaccount where accno=? and bankname=? and email=? ");
		    pst.setInt(1, accno);
		    pst.setString(2, bankname);
		    pst.setString(3, mail);
		    rs=pst.executeQuery();
		    if(rs.next())
			{
		    	 pst=con.prepareStatement("update usersdata set accountno=? where userid=?");
				    pst.setInt(1, accno);
				    pst.setString(2, id);
				    int r=pst.executeUpdate();
		    	 	if(r>0)
		    	 		response.sendRedirect("Customer.jsp");
		    	    else 
		    	    	response.sendRedirect("failure.jsp");
				
			}
		    
		    
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
