package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybeans.DBConnector;

/**
 * Servlet implementation class changeAdminPass
 */
@WebServlet("/changeAdminPass")
public class changeAdminPass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public changeAdminPass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String uid=request.getParameter("uid");
		String cpass=request.getParameter("cpass");
		String npass=request.getParameter("npass");
		
		
		Connection con;
		PreparedStatement pst;
		
		try
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst=con.prepareStatement("update userlogin set pswd=? where userid=? and pswd=?;");
			pst.setString(1, npass);
			pst.setString(2, uid);
			pst.setString(3, cpass);
			int cnt=pst.executeUpdate();
			
			if(cnt==1)
				out.println("<h4>Password Changed Successfully.</h4>");
			else
				out.println("<h4>Process Failed</h4>");
			
			out.print("<br><a href='AdminPanel.jsp'>Home</a>");
			con.close();
			
			response.sendRedirect("logout.jsp");
			
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

}
