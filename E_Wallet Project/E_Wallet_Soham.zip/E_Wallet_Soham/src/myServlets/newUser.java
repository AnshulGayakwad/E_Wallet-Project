package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mybeans.DBConnector;

/**
 * Servlet implementation class newUser
 */
@WebServlet("/newUser")
public class newUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public newUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		String uid=request.getParameter("uid");
		String mail=request.getParameter("mail");
		String name=request.getParameter("name");
		String mobile=request.getParameter("mobile");
		String question=request.getParameter("question");
		String answer=request.getParameter("answer");
		String pass=request.getParameter("conpass");

		
		Connection con;
		PreparedStatement pst;
		
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst= con.prepareStatement("insert into userlogin values(?,?,default,default);");
			pst.setString(1, uid);
			pst.setString(2, pass);
			pst.executeUpdate();
			
			
			pst=con.prepareStatement("insert into usersdata (userid, name, email, mobileno, question, answer, date) values(?,?,?,?,?,?, now());");
			pst.setString(1, uid);
			pst.setString(2, name);
			pst.setString(3, mail);
			pst.setString(4, mobile);
			pst.setString(5, question);
			pst.setString(6, answer);
			pst.executeUpdate();
			
			HttpSession ses=request.getSession(true);
			ses.setAttribute("userid", uid);
			
			con.close();
			
			
			response.sendRedirect("kyc.jsp");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
