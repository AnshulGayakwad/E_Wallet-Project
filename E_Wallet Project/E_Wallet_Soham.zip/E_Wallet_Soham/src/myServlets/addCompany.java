package myServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mybeans.DBConnector;

/**
 * Servlet implementation class addCompany
 */
@WebServlet("/addCompany")
public class addCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		int a = ThreadLocalRandom.current().nextInt();   
    	String wid=String.valueOf(a).substring(1,7);
		
		String cid=request.getParameter("cid");
		String cname=request.getParameter("cname");
		String ctype=request.getParameter("ctype");
		Double balance=Double.parseDouble(request.getParameter("balance"));
		
		Connection con;
		PreparedStatement pst;
		
		try 
		{
			DBConnector dbc=new DBConnector();
			con=dbc.getDbconnection();
			pst= con.prepareStatement("insert into companydata values(?, ?, ?, now(), ?, ?)");
			pst.setString(1, cid);
			pst.setString(2, cname);
			pst.setString(3, wid);
			pst.setString(4, ctype);
			pst.setDouble(5, balance);
			int cnt=pst.executeUpdate();
			
			if (cnt>0)
			{
				response.sendRedirect("succeccCompantAdd.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
